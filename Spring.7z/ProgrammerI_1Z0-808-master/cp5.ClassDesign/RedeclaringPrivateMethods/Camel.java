package RedeclaringPrivateMethods;

public class Camel {
	
	private String getNumberOfHumps() {
		return "Undefined";
	}
}
