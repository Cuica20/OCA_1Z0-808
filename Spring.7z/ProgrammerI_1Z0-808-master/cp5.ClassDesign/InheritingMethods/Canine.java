package InheritingMethods;

public class Canine {
	public double getAverageWeight() {
		return 50;
	}
}
