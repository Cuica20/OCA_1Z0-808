package InheritingVariables;

public class Animal {
	
	public int length = 2;
	
}