package HidingStaticMethods;

public class Bear {
	
	public static void eat() {
		System.out.println("Bear is eating");
	}

}
