package cp5.classdesing.inheriting;

public class Dog extends Animal {

	void sound(){
		System.out.println("Bark");		
	}
	
}
