package cp5.classdesing.inheriting;

public class Animal {

	void run(){
		System.out.println("Animal Run");
	}
	
}
