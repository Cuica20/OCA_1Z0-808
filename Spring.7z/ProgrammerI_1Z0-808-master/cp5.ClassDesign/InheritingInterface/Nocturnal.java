package InheritingInterface;

public interface Nocturnal {
	
	default boolean isBlind() { return true; }

}
