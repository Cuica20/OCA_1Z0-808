package UnderstandingPolymorphism;

public class Primate {
	public boolean hasHair() {
		return true;
	}
}