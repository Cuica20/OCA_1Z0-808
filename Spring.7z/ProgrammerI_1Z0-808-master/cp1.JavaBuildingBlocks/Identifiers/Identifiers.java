package Identifiers;

public class Identifiers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	//Compila
	String $name = "Sara";
	String _name = "Sara";
	String $name1 = "Sara";
	String _name2 = "Sara";
	
	//Não Compila
//	String %name = "Sara";
//	String *name = "Sara";
//	String @name = "Sara";
//	String #name = "Sara";

	}

}
