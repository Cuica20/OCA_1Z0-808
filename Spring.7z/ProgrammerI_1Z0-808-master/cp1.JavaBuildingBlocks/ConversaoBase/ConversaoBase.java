package ConversaoBase;

public class ConversaoBase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s = null;
		
	
		
		//O primeiro mais a direita é 6, então vale 6, o segundo é 5 então vale 50 (5 X 10 por ser base 10). 50 + 6 = 56
		System.out.println(56); // 56
		
		System.out.println("\n");
		
		//O primeiro mais a direita é 1, então vale 1, o segundo é 1 então vale 2 (1 X 2 por ser base 2). 2 + 1 = 3
		System.out.println(0b11); // 3		
		
		System.out.println("\n");
		//O primeiro mais a direita é 7, então vale 7, o segundo é 1 então vale 8 (1 X 8 por ser base 8). 8 + 7 = 15
		System.out.println(017); // 15
				
		
		System.out.println("\n");		
		// O primeiro mais a direita é F, então vale 15, o segundo é 1 então vale 16 (1 X 16 por ser base octagonal). 15 + 16 = 31
		System.out.println(0x1F); // 31
		
		
		
	}

}
