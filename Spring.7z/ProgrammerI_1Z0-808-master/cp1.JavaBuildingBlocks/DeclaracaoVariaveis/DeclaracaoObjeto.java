package DeclaracaoVariaveis;

public class DeclaracaoObjeto {

//	static String name = "web";
	
	
	
	public static void main(String[] args){
		
		DeclaracaoObjeto DO;
		
		String name;
		
		int i[] = {};
		
		System.out.println(i);
		
	}
	
	
}
