package Subclass;

public class Hopper {
	public void hop() { }
}
