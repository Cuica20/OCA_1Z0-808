package Subclass;

public class CanNotHopException extends Exception{

}
