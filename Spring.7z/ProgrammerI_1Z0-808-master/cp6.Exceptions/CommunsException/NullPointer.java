package CommunsException;

public class NullPointer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s = null;
		int i = s.length();
		
		System.out.println(i);
		
	}

}
