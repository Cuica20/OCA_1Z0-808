package lambdaExpressions;

public interface CheckTrait {
	boolean test(Animal a);
}
