package designingMethods;

public class MethodBody {

	
	public void walk1() { }
	
	//Obrigatório parenteses após o nome do método.
	//public void walk2; // DOES NOT COMPILE
	
	public void walk3(int a) { int name = 5; }
	
}
