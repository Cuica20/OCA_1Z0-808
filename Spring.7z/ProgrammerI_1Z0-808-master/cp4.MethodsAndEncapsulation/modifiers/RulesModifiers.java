package modifiers;

public class RulesModifiers {
	
	
	//São estes os quatro modificadores de acesso, do mais restritivo ao menos restritivo.
	
	
	//private: Only accessible within the same class
	
	//default (package private) access: private and other classes in the same package
	
	//protected: default access and child classes	
	
	//public: protected and classes in the other packages
	
	
	
}
