package staticMethodsAndFields;

public class Koala {
	
	
	public static int count = 0; // static variable
	public static void main(String[] args) { // static method
	System.out.println(count);
	}
	
	
}
