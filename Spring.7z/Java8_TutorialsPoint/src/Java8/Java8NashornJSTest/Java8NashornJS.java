/**
 * 
 */
package Java8.Java8NashornJSTest;

/**
 * @author jcuicapuza
 *
 */
public class Java8NashornJS {

}
