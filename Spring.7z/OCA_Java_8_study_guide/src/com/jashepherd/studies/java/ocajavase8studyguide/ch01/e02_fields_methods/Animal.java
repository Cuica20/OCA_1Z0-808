package com.jashepherd.studies.java.ocajavase8studyguide.ch01.e02_fields_methods;

/**
 * Chapter 1: Java Building Blocks<br>
 * Understanding the Java Class Structure<br>
 * Fields and Methods - page 3
 * <p>
 * This is a very simple Java class with a field
 */
public class Animal {
	String name;
}
