package com.jashepherd.studies.java.ocajavase8studyguide.ch03.e01_creating_manipulating_strings;

/**
 * Chapter 3: Core Java APIs<br>
 * Creating and Manipulating Strings<br>
 * page 102
 */
public class StringBasics {
	// these two statements both create a String object
	String name = "Fluffy";  // Strings are special - don't have to be instantiated with 'new'
	String name1 = new String("Fluffy");
}
