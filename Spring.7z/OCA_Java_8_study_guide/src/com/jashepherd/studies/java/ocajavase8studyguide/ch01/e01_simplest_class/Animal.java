package com.jashepherd.studies.java.ocajavase8studyguide.ch01.e01_simplest_class;

/**
 * Chapter 1: Java Building Blocks<br>
 * Understanding the Java Class Structure<br>
 * Fields and Methods - page 3
 * <p>
 * This is the simplest Java class that can be written
 */
class Animal {}
