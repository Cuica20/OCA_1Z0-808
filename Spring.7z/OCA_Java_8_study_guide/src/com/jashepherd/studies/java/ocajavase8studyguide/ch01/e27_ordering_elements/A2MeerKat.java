/* header */
package com.jashepherd.studies.java.ocajavase8studyguide.ch01.e27_ordering_elements;

/**
 * Chapter 1: Java Building Blocks<br/>
 * Ordering Elements in a Class<br/>
 * page 35
 * <p>
 * Comments can go anywhere and imports are optional
 */
// class Meerkat
public class A2MeerKat {}
