// import java.util.*
package com.jashepherd.studies.java.ocajavase8studyguide.ch01.e27_ordering_elements;  // WOULD NOT COMPILE

//String name;  // WOULD NOT COMPILE
/**
 * Chapter 1: Java Building Blocks<br/>
 * Ordering Elements in a Class<br/>
 * page 35
 */
public class A3Meerkat {}
