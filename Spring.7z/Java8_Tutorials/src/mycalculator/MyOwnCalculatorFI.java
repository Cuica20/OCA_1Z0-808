package mycalculator;

/**
 * Created with IntelliJ IDEA.
 * User: usta
 * Date: 2/1/13
 * Time: 8:28 PM
 * To change this template use File | Settings | File Templates.
 */
public interface MyOwnCalculatorFI<T> {

    public T calcIt(T t1, T t2);
}
