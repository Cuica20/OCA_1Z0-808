package bodytypes;

/**
 * Created with IntelliJ IDEA.
 * User: usta
 * Date: 12/13/12
 * Time: 5:27 PM
 * To change this template use File | Settings | File Templates.
 */
public interface MyIntegerCalculator {

    public Integer calcIt(Integer s1);

}
