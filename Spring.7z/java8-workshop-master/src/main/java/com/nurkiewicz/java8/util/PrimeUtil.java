package com.nurkiewicz.java8.util;

import java.util.function.LongUnaryOperator;
import java.util.stream.LongStream;

public class PrimeUtil {

	/**
	 * TODO: Try to implement this without loops and if's
	 * @see LongStream#iterate(long, LongUnaryOperator)
	 */
	public static long nextPrimeAfter(long x) {
		throw new UnsupportedOperationException("nextPrimeAfter()");
	}

	/**
	 * TODO: Try to implement this without loops and if's
	 * @see LongStream#range(long, long)
	 */
	public static boolean isPrime(long x) {
		throw new UnsupportedOperationException("isPrime()");
	}

}
