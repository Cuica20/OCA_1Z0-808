package com.nurkiewicz.java8.stackoverflow;

public class Question {
}