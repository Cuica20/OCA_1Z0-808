package com.nurkiewicz.java8.people;

public enum Sex {

	MALE, FEMALE

}
