package com.nurkiewicz.java8;

@FunctionalInterface
interface RandomSource {

	int oneOrMinusOne();

}
