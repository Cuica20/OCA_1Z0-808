package com.nurkiewicz.java8.defmethods;

public class RuleEngine {

	public String start() {
		return "RuleEngine";
	}
}
