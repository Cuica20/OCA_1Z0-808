Construir Programas Funcionales
--------

[![Analytics](https://ga-beacon.appspot.com/UA-74043032-1/malobato/java8-the-missing-tutorial/07-building-functional-programs)](https://github.com/igrigorik/ga-beacon)
