Completable Futures
------



[![Analytics](https://ga-beacon.appspot.com/UA-59411913-3/shekhargulati/java8-the-missing-tutorial/09-completable-futures)](https://github.com/igrigorik/ga-beacon)
