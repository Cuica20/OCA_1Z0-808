package com.shekhargulati.java8_tutorial.ch02;

/**
 * Example of @FunctionalInterface
 */

@FunctionalInterface
public interface InvalidFunctionInterface {

    public boolean test();

//    public boolean test1();


}


