package com.shekhargulati.java8_tutorial.domain;

public enum TaskType {

	READING, CODING, BLOGGING
}
