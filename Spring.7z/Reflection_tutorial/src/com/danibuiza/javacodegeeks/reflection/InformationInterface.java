package com.danibuiza.javacodegeeks.reflection;

public interface InformationInterface
{

    public String getInfo();
}
