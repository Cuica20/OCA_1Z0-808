package com.danibuiza.javacodegeeks.reflection;

/**
 * Class to show the usage of static elements in reflection
 * 
 * @author dgutierrez-diez
 */
public class Counter
{

    public static int counter = 33;
}
