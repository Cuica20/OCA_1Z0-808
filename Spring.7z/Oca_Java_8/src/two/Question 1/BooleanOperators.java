public class BooleanOperators {

	public static void main(String[] args){
		boolean a;
		boolean b;

		System.out.println(a==b); // A
		//System.out.println(a+);
		//System.out.println(a--);
		System.out.println(!b); // D
		//System.out.println(a%b);
		//System.out.println(a<=b);
	}

}