package animals;
class Rabbit {}