class Rabbit {}
import java.util.*;
package animals;