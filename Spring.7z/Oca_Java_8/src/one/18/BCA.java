import java.util.*;
package animals;
class Rabbit {}