import java.util.*;
class Rabbit {}