class Rabbit {}
import java.util.*;