package animals;
import java.util.*;
class Rabbit {}