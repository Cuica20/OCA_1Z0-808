class Rabbit {}
package animals;