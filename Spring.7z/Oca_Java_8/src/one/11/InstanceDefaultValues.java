public class InstanceDefaultValues {

	double varDouble;
	int varInt;
	String varString;

	public static void main(String[] args) {
		System.out.println("default vaule of double instance variable is "+varDouble);
		System.out.println("default vaule of int instance variable is "+varInt);
		System.out.println("default vaule of String instance variable is "+varString);		
} }