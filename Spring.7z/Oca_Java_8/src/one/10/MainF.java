public class MainF {
	public static main(String[] args) {
		
} }