public class MainD {
	public static void test(String[] args) {
		
} }