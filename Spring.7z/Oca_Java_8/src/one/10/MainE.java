public class MainE {
	public static void main(String[] args) {
		
} }