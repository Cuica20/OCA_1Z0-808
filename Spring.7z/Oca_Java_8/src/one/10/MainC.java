public class MainC {
	public void main(String[] args) {
		
} }