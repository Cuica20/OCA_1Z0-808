public class MainA {
	private static void main(String[] args) {
		
} }