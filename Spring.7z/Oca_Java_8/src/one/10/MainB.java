public class MainB {
	public static final main(String[] args) {
		
} }