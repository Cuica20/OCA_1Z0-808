public class LocalVariableDefaultValues {

	public static void main(String[] args) {
		boolean varBoolean
		float varFloat;
		Object varObject;

		System.out.println("default vaule of local boolean variable variable is "+varBoolean);
		System.out.println("default vaule of local float variable variable is "+varFloat);
		System.out.println("default vaule of local Object variable variable is "+varObject);		
} }