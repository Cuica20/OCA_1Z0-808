public class Bunny {
	public static void main(String[] args) {
		Bunny bun = new Bunny();
	}
}