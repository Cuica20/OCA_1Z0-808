/**
 * @author mxsb
 */
public class Snake {
	// String result = "done";
	public void shed(boolean time) {
		// String result = "done";
		if(time) {
			// String result = "done";
		}
		System.out.println(result);
		// String result = "done";
	}
}