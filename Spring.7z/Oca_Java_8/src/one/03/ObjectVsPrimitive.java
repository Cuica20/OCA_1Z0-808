public class ObjectVsPrimitive {

	public static void main(String[] args) {
		short numPets = 5;
		int numGrains = 5.6;
		String name = "Scruffy";
		numPets.length();
		numGrains.length();
		name.length();
	}
}