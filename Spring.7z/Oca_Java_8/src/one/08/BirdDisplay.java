public class BirdDisplay {
	public static void main(String[] name) {
		System.out.println(name[1]);
} }