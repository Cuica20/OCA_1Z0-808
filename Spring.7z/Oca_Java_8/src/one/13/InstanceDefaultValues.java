public class InstanceDefaultValues {

	boolean varBoolean;
	int varInt;
	

	public static void main(String[] args) {
		System.out.println("default vaule of boolean instance variable is "+varBoolean);
		System.out.println("default vaule of int instance variable is "+varInt);	
} }