package aquarium;
import java.lang.*;
import java.lang.System;
import aquarium.Water;
import aquarium.*;
public class Tank {
	public void print(Water water) {
		System.out.println(water); } }