//Questing A

package my.directory.named.a;

public class Bird {}

//Questing B
/*
package my.directory.named.A;

public class Bird {}
*/

//Questing C
/*
package named.a;

public class Bird {}
*/

//Questing D
/*
package named.A;

public class Bird {}
*/

//Questing E
/*
package a;

public class Bird {}
*/

//Questing F
/*
package A;

public class Bird {}
*/