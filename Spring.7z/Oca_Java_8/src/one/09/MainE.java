public class MainE {
	public static void main(String... $n) {
		
} }