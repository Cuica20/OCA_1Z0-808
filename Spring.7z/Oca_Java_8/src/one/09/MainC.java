public class MainC {
	public static void main(String abc[]) {
		
} }