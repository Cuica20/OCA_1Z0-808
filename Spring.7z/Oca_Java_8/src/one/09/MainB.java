public class MainB {
	public static void main(String[] 123) {
		
} }