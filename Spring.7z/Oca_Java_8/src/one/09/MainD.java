public class MainD {
	public static void main(String _Names[]) {
		
} }