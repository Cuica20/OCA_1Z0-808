public class MainA {
	public static void main(String[] _names) {
		
} }