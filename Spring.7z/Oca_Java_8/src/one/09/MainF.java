public class MainF {
	public static void main(String names) {
		
} }