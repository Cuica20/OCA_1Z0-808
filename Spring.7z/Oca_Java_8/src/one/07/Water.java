package aquarium;
public class Water {
	boolean salty = false;
}