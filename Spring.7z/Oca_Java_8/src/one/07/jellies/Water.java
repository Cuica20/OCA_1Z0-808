package aquarium.jellies;
public class Water {
	boolean salty = true;
}