package employee;
// import aquarium.*;

// import aquarium.Water;
// import aquarium.jellies.*;

// import aquarium.*;
// import aquarium.jellies.Water;

// import aquarium.*;
// import aquarium.jellies.*;

// import aquarium.Water;
// import aquarium.jellies.Water;
public class WaterFiller {
	Water water;
}