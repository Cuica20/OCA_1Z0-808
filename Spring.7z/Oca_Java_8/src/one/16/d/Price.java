public class Price {
	public void admission() {
		double amount = 0xE;
		System.out.println(amount);
	}
}