public class Price {
	public void admission() {
		int amount = 9L;
		System.out.println(amount);
	}
}