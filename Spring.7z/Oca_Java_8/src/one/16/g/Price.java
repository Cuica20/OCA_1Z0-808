public class Price {
	public void admission() {
		INSERT CODE HERE
		System.out.println(amount);
	}
}