public class Price {
	public void admission() {
		int amount = 1_2_;
		System.out.println(amount);
	}
}