public class Price {
	public void admission() {
		int amount = 0b101;
		System.out.println(amount);
	}
}