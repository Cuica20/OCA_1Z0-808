public class Price {
	public void admission() {
		int amount = 0xE;
		System.out.println(amount);
	}
}