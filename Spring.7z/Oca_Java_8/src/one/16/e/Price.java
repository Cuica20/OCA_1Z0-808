public class Price {
	public void admission() {
		double amount = 1_2_.0_0;
		System.out.println(amount);
	}
}