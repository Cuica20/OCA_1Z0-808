package aquarium;
public class Tank { }