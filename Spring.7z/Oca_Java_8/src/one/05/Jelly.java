package aquarium.jellies;
public class Jelly { }