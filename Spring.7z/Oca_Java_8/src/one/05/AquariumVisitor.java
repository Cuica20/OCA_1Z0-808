package visitor;
// import aquarium.*;
// import aquarium.*.Jelly;
// import aquarium.jellies.Jelly;
// import aquarium.jellies.*;
public class AquariumVisitor {
	public void admire(Jelly jelly) { } }